#Copyright (c) 2026 Gene B. Denney. All Rights Reserved.

from pangolin.core.interfaces import SkillManagerDynamic

SCHEMA = {
    "name": "load_skill",
    "description": "Use to load a skill from the available skills into the session context.",
    "parameters": {
        "type": "object",
        "properties": {
            "skill_name": {"type": "string"}},
        "required": ["skill_name"],
    },
}

def make_session_aware_run(session):
    def run(skill_name: str) -> str:
        try:
            if session.skill_manager and isinstance(session.skill_manager, SkillManagerDynamic):
                session.skill_manager.load_skill(skill_name)
                return f'{skill_name} loaded'
            return 'Current skill manager does not implement SkillMangerDynamic'
        except Exception as e:
            return f"Couldn't read {skill_name}: {e}"

    return run